import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home {

//   openAccountClicked(event: Event) {
//   event.preventDefault(); // এইটা href="#" এর ডিফল্ট রিলোড আটকে রাখে
//   alert('Before opening an account, you must be a registered user.\n' +
//     'If you are not a user, please go to the Add User page.\n' +
//     'If you are already a user, please go to the Login page.');
// }

}
