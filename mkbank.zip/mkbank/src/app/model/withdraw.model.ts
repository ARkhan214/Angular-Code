export class Withdraw {

  accountId!: string;       
  amount!: number;           
  transactionDate!: Date;     
  transactionId?: string;    
  description?: string;   
      
}