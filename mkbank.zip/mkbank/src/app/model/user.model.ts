export class User{


    id?:string;
    name!:string;
    email!:string;
    password!:string;
    type !:string;
    photoUrl?: string;  // 
    
    // accId?:string;






    // accounts !:{
    // id :string;
    // userId :string;
    // type :string;
    // balance :number;
    // userName?: string;     
    // status: 'Active' | 'Closed';
    // }
    
}